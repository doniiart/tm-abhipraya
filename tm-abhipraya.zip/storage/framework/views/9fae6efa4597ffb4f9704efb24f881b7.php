<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <!-- Header Halaman -->
            <div class="mb-8">
                <span class="text-xs font-bold tracking-widest text-slate-400 uppercase">Transparansi Inventaris</span>
                <h1 class="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">Laporan Persewaan</h1>
                <p class="text-sm text-slate-500 mt-1">Daftar ketersediaan barang inventaris dan catatan peminjaman.</p>
                <div class="mt-6">
                    <a href="<?php echo e(url('/')); ?>#bagian-laporan" class="inline-flex items-center justify-center px-6 py-2.5 bg-white border border-slate-200 rounded-full text-xs font-bold text-slate-600 hover:bg-slate-50 hover:text-slate-900 transition-colors shadow-sm">
                        &larr; Kembali ke Menu Laporan
                    </a>
                </div>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                
                <!-- BAGIAN 1: TABEL DAFTAR ASET (KETERSEDIAAN) -->
                <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                    <div class="p-6 border-b border-gray-100 bg-gray-50/50">
                        <h3 class="font-bold text-gray-900 flex items-center gap-2">
                            <div class="w-2 h-2 rounded-full bg-emerald-500"></div>
                            Daftar Nama Aset Karang Taruna
                        </h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-gray-50 border-b border-gray-100 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                                <tr>
                                    <th class="py-3 px-4 w-12 text-center">NO</th>
                                    <th class="py-3 px-4">NAMA BARANG</th>
                                    <th class="py-3 px-4 text-center">JUMLAH</th>
                                    <th class="py-3 px-4 text-center">KONDISI</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50 text-xs sm:text-sm">
                                <?php $__empty_1 = true; $__currentLoopData = $asets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $aset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="hover:bg-slate-50 transition-colors">
                                        <td class="py-3 px-4 text-center text-slate-400"><?php echo e($index + 1); ?></td>
                                        <td class="py-3 px-4 font-bold text-slate-800"><?php echo e($aset->nama_aset); ?></td>
                                        <td class="py-3 px-4 text-center font-bold <?php echo e($aset->jumlah == 0 ? 'text-red-500' : 'text-slate-700'); ?>"><?php echo e($aset->jumlah); ?></td>
                                        <td class="py-3 px-4 text-center">
                                            <?php if($aset->kondisi == 'Baik'): ?>
                                                <span class="text-emerald-600 font-semibold bg-emerald-50 px-2 py-1 rounded">Baik</span>
                                            <?php else: ?>
                                                <span class="text-amber-600 font-semibold bg-amber-50 px-2 py-1 rounded"><?php echo e($aset->kondisi); ?></span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="4" class="py-8 text-center text-slate-500">Belum ada data barang.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- BAGIAN 2: TABEL SEDANG DISEWA -->
                <div class="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden">
                    <div class="p-6 border-b border-gray-100 bg-gray-50/50">
                        <h3 class="font-bold text-gray-900 flex items-center gap-2">
                            <div class="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></div>
                            Barang Sedang Disewa
                        </h3>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-gray-50 border-b border-gray-100 text-[10px] uppercase tracking-widest text-slate-400 font-bold">
                                <tr>
                                    <th class="py-3 px-4">PENYEWA</th>
                                    <th class="py-3 px-4">BARANG</th>
                                    <th class="py-3 px-4 text-center">TGL SEWA</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-50 text-xs sm:text-sm">
                                <?php $__empty_1 = true; $__currentLoopData = $sewas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sewa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr class="hover:bg-slate-50 transition-colors">
                                        <td class="py-3 px-4">
                                            <p class="font-bold text-slate-800"><?php echo e($sewa->nama_penyewa); ?></p>
                                            <p class="text-[11px] text-slate-500 mt-0.5"><?php echo e($sewa->alamat); ?></p>
                                        </td>
                                        <td class="py-3 px-4">
                                            <p class="font-bold text-blue-600"><?php echo e($sewa->aset->nama_aset ?? '-'); ?></p>
                                            <p class="text-[11px] text-slate-500 font-semibold mt-0.5"><?php echo e($sewa->jumlah_pinjam); ?> unit</p>
                                        </td>
                                        <td class="py-3 px-4 text-center text-slate-600 font-medium">
                                            <?php echo e(\Carbon\Carbon::parse($sewa->tanggal_sewa)->format('d/m/Y')); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td colspan="3" class="py-8 text-center text-slate-500 font-medium">
                                            Saat ini tidak ada barang yang disewa.
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\hp\tm-abhipraya\resources\views/persewaan/laporan_publik.blade.php ENDPATH**/ ?>