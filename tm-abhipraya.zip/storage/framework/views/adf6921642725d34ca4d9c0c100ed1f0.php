<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Karang Taruna Abhipraya')); ?></title>

        <!-- Font Modern: Plus Jakarta Sans -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
        <link rel="icon" href="<?php echo e(asset('logo.png')); ?>" type="image/png">
        <!-- Scripts -->
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        
        <style>
            body { font-family: 'Plus Jakarta Sans', sans-serif; }
        </style>

        <script src="https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.page.js" defer></script>
        <script>
        window.OneSignalDeferred = window.OneSignalDeferred || [];
        OneSignalDeferred.push(async function(OneSignal) {
            await OneSignal.init({
            appId: "<?php echo e(config('services.onesignal.app_id')); ?>",
            });
        });
        </script>
    </head>
    <body class="antialiased bg-gray-50 text-gray-900">
        <div class="min-h-screen">
            
            <!-- Memanggil File Navbar -->
            <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- Header Halaman -->
            <?php if(isset($header)): ?>
                <header class="bg-white shadow-sm border-b border-gray-100">
                    <div class="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
                        <?php echo e($header); ?>

                    </div>
                </header>
            <?php endif; ?>

            <!-- Isi Konten Halaman -->
            <main>
                <?php echo e($slot); ?>

            </main>
        </div>
    </body>
</html><?php /**PATH C:\Users\hp\tm-abhipraya\resources\views/layouts/app.blade.php ENDPATH**/ ?>