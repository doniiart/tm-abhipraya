<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-slate-50 min-h-screen">
        <div class="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
            
            <!-- Header Halaman -->
            <div class="text-center mb-10">
                <h1 class="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight mb-3">Galeri & Kegiatan<br>Terbaru</h1>
                <p class="text-sm text-slate-500 max-w-md mx-auto">Pilih kategori di bawah untuk melihat dokumentasi kegiatan Karang Taruna.</p>
                
                <!-- Filter Kategori (Desain Statis untuk Tampilan) -->
                <div class="flex flex-wrap justify-center gap-2 mt-6">
                    <button type="button" class="px-5 py-2 bg-slate-900 text-white text-xs font-bold rounded-full shadow-md focus:outline-none transition-all select-none">Semua</button>
                    <button type="button" class="px-5 py-2 bg-white text-slate-600 text-xs font-bold rounded-full border border-slate-200 hover:bg-slate-50 hover:text-slate-900 active:bg-slate-100 active:text-slate-900 focus:outline-none focus:text-slate-900 transition-all select-none">Kumpulan Rutin</button>
                    <button type="button" class="px-5 py-2 bg-white text-slate-600 text-xs font-bold rounded-full border border-slate-200 hover:bg-slate-50 hover:text-slate-900 active:bg-slate-100 active:text-slate-900 focus:outline-none focus:text-slate-900 transition-all select-none">Bakti Sosial</button>
                    <button type="button" class="px-5 py-2 bg-white text-slate-600 text-xs font-bold rounded-full border border-slate-200 hover:bg-slate-50 hover:text-slate-900 active:bg-slate-100 active:text-slate-900 focus:outline-none focus:text-slate-900 transition-all select-none">Kepemudaan</button>
                </div>
            </div>

            <!-- Grid Galeri Dinamis -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                <?php $__empty_1 = true; $__currentLoopData = $kegiatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- Kartu Item Kegiatan -->
                <div class="bg-white rounded-3xl overflow-hidden shadow-sm border border-slate-100 hover:shadow-lg transition-shadow duration-300">
                    <!-- Foto -->
                    <div class="aspect-video w-full overflow-hidden bg-slate-100">
                        <img src="<?php echo e(asset('storage/' . $item->foto)); ?>" alt="<?php echo e($item->judul); ?>" class="w-full h-full object-cover hover:scale-105 transition-transform duration-500">
                    </div>
                    <!-- Konten Teks -->
                    <div class="p-6">
                        <span class="inline-block px-3 py-1 bg-blue-50 text-blue-600 text-[10px] font-bold uppercase tracking-widest rounded-full mb-3">
                            <?php echo e($item->kategori ?? 'Bakti Sosial'); ?>

                        </span>
                        <h2 class="text-lg font-bold text-slate-900 mb-2 leading-tight"><?php echo e($item->judul); ?></h2>
                        <p class="text-xs text-slate-500 line-clamp-3 leading-relaxed">
                            <?php echo e($item->deskripsi); ?>

                        </p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <!-- Tampilan jika database masih kosong -->
                <div class="col-span-full text-center py-12">
                    <p class="text-slate-500">Belum ada kegiatan yang diunggah.</p>
                </div>
                <?php endif; ?>

            </div>
            
            <!-- Tombol Kembali -->
            <div class="mt-10 text-center">
                <a href="<?php echo e(url('/')); ?>" class="inline-block px-6 py-2.5 bg-white border border-slate-200 rounded-full text-xs font-bold text-slate-600 hover:bg-slate-50 transition shadow-sm">
                    &larr; Kembali ke Beranda
                </a>
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\hp\tm-abhipraya\resources\views/kegiatan/publik.blade.php ENDPATH**/ ?>